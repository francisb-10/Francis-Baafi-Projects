"""
This module is responsible for the overall program flow. It controls how the user interacts with the
program and how the program behaves. It uses the other modules to interact with the user, carry out
processing, and for visualising information.

Note:   any user input/output should be done in the module 'tui'
        any processing should be done in the module 'process'
        any visualisation should be done in the module 'visual'
"""


def display_title(title):
    # Display dashes above the title
    dashes = '-' * len(title)
    print(dashes)

    # Display the title
    print("Disneyland Review Analyser")

    # Display dashes below the title
    dashes = '-' * len(title)
    print(dashes)


# Example usage with the specified title
program_title = "Disneyland Review Analyser"
display_title(program_title)

import csv


def read_csv_file(file_path):
    data_list = []

    try:
        with open(file_path, "r", newline="") as csvfile:
            csv_reader = csv.reader(csvfile)
            # Skip the header if it exists
            header = next(csv_reader, None)

            for row in csv_reader:
                data_list.append(row)

        print("Dataset has been successfully read.")
        print(f"Number of rows in the dataset: {len(data_list)}")

        return data_list  # Return the data_list

    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")
        return None


# Specify the path to your CSV file
csv_file_path = "data/disneyland"

# Call the function to read the CSV file
dataset = read_csv_file(csv_file_path)


# Now 'dataset' contains the loaded data from the CSV file and can be used in later tasks


def display_menu():
    print("Please enter the letter which corresponds with your desired menu choice:")
    print("[A] View Data")
    print("[B] Visualise Data")
    print("[X] Exit")


def display_Submenu_A():
    print("Sub-menu for Option A:")
    print("[A] View Reviews by Park")
    print("[B] Number of Reviews by Park and Reviewer Location")
    print("[C] Average Score per year by Park")
    print("[D] Average Score per Park by Reviewer Location")


def display_submenu_b():
    print("Sub-menu for Option B:")
    print("[A] Most Reviewed Parks")
    print("[B] Average Scores")
    print("[C] Park Ranking by Nationality")
    print("[D] Most Popular Month by Park")

def display_reviews_for_park(data, park_name):
    # Find reviews for the specified park
    park_reviews = [row for row in dataset[1:] if row[1] == park_name]

    # Check if there are reviews for the specified park
    if not park_reviews:
        print(f"No reviews found for {park_name}.")
    else:
        # Display reviews for the specified park
        print(f"Reviews for {park_name}:")
        for review in park_reviews:
            print(", ".join(review))

# Continuous loop
while True:
    # Display the menu
    display_menu()

    # Retrieve user input for selection
    user_selection = input("Please Enter your Choice (A, B, or X): ")

    # Process the user's selection
    if user_selection.upper() == 'A':
        print("You selected: View Data")
        display_Submenu_A()

        # Retrieve the user's input for Sub-menu selection
        Sub_menu_selection = input("Please Enter your Sub-menu selection (A, B, C, or D): ")

        # Process the user's Sub-menu selection
        if Sub_menu_selection.upper() == 'A':
            print("You selected: View Reviews by Park")

            # Ask the user for the park name
            park_name = input("Enter the name of the park to view reviews for: ")

            # Example usage
            display_reviews_for_park(dataset, "Disneyland Park")

        elif Sub_menu_selection.upper() == 'B':
            print("You selected: Number of Reviews by Park and Reviewer Location")

            # Ask the user for the park name and reviewer location
            park_name = input("Enter the name of the park: ")
            reviewer_location = input("Enter the reviewer's location: ")

            # Count reviews for the specified park and reviewer location
            count_reviews_by_park_and_location(dataset, park_name, reviewer_location)

        elif Sub_menu_selection.upper() == 'C':
            print("You selected: Average Score per Year by Park")

            # Ask the user for the park name and year
            park_name = input("Enter the name of the park: ")
            target_year = input("Enter the target year: ")

            # Call the function (make sure it's defined above this point)
            average_score_per_year_by_park(dataset, park_name, target_year)

        elif Sub_menu_selection.upper() == 'D':
            print("You selected: Average Score per Park by Reviewer Location")
        else:
            print("Invalid Input for Sub-menu Selection. Please Enter A, B, C, or D.")

    elif user_selection.upper() == 'B':
        print("You selected: Visualise Data")
        display_submenu_b()

        # Get user input for sub-menu selection
        sub_menu_selection = input("Enter your sub-menu selection (A, B, C, or D): ")

        # Process the user's sub-menu selection
        if sub_menu_selection.upper() == 'A':
            print("You selected: Most Reviewed Parks")
            # Call the function (make sure it's defined above this point)
            display_reviews_for_park(dataset, park_name)
        elif sub_menu_selection.upper() == 'B':
            print("You selected: Average Scores")
            # Add code to handle sub-menu option B
        elif sub_menu_selection.upper() == 'C':
            print("You selected: Park Ranking by Nationality")
            # Add code to handle sub-menu option C
        elif sub_menu_selection.upper() == 'D':
            print("You selected: Most Popular Month by Park")
            # Add code to handle sub-menu option D

        elif sub_menu_selection.upper() == 'A':
            print("You selected: Most Reviewed Parks")
            # Plot the pie chart showing the number of reviews each park has received
            plot_reviews_per_park(dataset)
        else:
            print("Invalid sub-menu selection. Please enter A, B, C, or D.")

    elif user_selection.upper() == 'X':
        print("You selected: Exit")
        break  # Exit the loop when users select exit
    else:
        print("Invalid selection. Please Enter Options A, B, or X.")
    # This loop will continue to display the menu again


# Assume 'dataset' contains the loaded data from the CSV file

